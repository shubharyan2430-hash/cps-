/* Dependency-free, local reader for ordinary XLSX workbooks (first worksheet). */
(function registerLocalXlsxReader(root) {
  "use strict";
  const ZIP_EOCD = 0x06054b50;
  const ZIP_CENTRAL = 0x02014b50;
  const ZIP_LOCAL = 0x04034b50;
  const MAX_XLSX_BYTES = 50 * 1024 * 1024;
  const MAX_XLSX_CELLS = 10_000_000;
  const RELATIONSHIPS_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";

  function readUInt16(bytes, offset) {
    if (offset + 2 > bytes.length) throw new Error("Malformed XLSX archive.");
    return bytes[offset] | (bytes[offset + 1] << 8);
  }

  function readUInt32(bytes, offset) {
    if (offset + 4 > bytes.length) throw new Error("Malformed XLSX archive.");
    return (bytes[offset] | (bytes[offset + 1] << 8) | (bytes[offset + 2] << 16) | (bytes[offset + 3] << 24)) >>> 0;
  }

  function findEndOfCentralDirectory(bytes) {
    const lowerBound = Math.max(0, bytes.length - 65_557);
    for (let offset = bytes.length - 22; offset >= lowerBound; offset -= 1) {
      if (readUInt32(bytes, offset) === ZIP_EOCD) return offset;
    }
    throw new Error("This file is not a valid XLSX ZIP archive.");
  }

  function indexZipEntries(bytes) {
    const eocd = findEndOfCentralDirectory(bytes);
    const entryCount = readUInt16(bytes, eocd + 10);
    let offset = readUInt32(bytes, eocd + 16);
    const decoder = new TextDecoder("utf-8");
    const entries = new Map();

    for (let index = 0; index < entryCount; index += 1) {
      if (readUInt32(bytes, offset) !== ZIP_CENTRAL) throw new Error("Malformed XLSX central directory.");
      const method = readUInt16(bytes, offset + 10);
      const compressedSize = readUInt32(bytes, offset + 20);
      const uncompressedSize = readUInt32(bytes, offset + 24);
      const nameLength = readUInt16(bytes, offset + 28);
      const extraLength = readUInt16(bytes, offset + 30);
      const commentLength = readUInt16(bytes, offset + 32);
      const localOffset = readUInt32(bytes, offset + 42);
      const nameStart = offset + 46;
      const nameEnd = nameStart + nameLength;
      if (nameEnd > bytes.length) throw new Error("Malformed XLSX entry name.");
      entries.set(decoder.decode(bytes.slice(nameStart, nameEnd)), { method, compressedSize, uncompressedSize, localOffset });
      offset = nameEnd + extraLength + commentLength;
    }
    return entries;
  }

  async function readZipEntry(bytes, entries, path) {
    const entry = entries.get(path);
    if (!entry) return null;
    if (readUInt32(bytes, entry.localOffset) !== ZIP_LOCAL) throw new Error("Malformed XLSX local entry.");
    const nameLength = readUInt16(bytes, entry.localOffset + 26);
    const extraLength = readUInt16(bytes, entry.localOffset + 28);
    const start = entry.localOffset + 30 + nameLength + extraLength;
    const end = start + entry.compressedSize;
    if (end > bytes.length) throw new Error("Malformed XLSX entry data.");
    const compressed = bytes.slice(start, end);
    if (entry.method === 0) return compressed;
    if (entry.method !== 8 || typeof DecompressionStream === "undefined") {
      throw new Error("This XLSX compression method is not supported by this version of Chrome.");
    }
    const stream = new Blob([compressed]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
    const inflated = new Uint8Array(await new Response(stream).arrayBuffer());
    if (entry.uncompressedSize && inflated.length !== entry.uncompressedSize) throw new Error("XLSX decompression check failed.");
    return inflated;
  }

  function xmlDocument(text, label) {
    const document = new DOMParser().parseFromString(text, "application/xml");
    if (document.getElementsByTagName("parsererror").length) throw new Error(`Could not parse ${label} in this XLSX file.`);
    return document;
  }

  function columnNumber(reference) {
    const letters = String(reference || "").match(/[A-Z]+/i);
    if (!letters) return 0;
    return letters[0].toUpperCase().split("").reduce((total, letter) => total * 26 + letter.charCodeAt(0) - 64, 0) - 1;
  }

  async function findFirstSheet(bytes, entries) {
    const decoder = new TextDecoder("utf-8");
    const workbookBytes = await readZipEntry(bytes, entries, "xl/workbook.xml");
    const relationBytes = await readZipEntry(bytes, entries, "xl/_rels/workbook.xml.rels");
    if (!workbookBytes || !relationBytes) throw new Error("This XLSX file does not contain a workbook sheet definition.");
    const workbook = xmlDocument(decoder.decode(workbookBytes), "workbook.xml");
    const relations = xmlDocument(decoder.decode(relationBytes), "workbook relationships");
    const sheet = workbook.getElementsByTagName("sheet")[0];
    if (!sheet) throw new Error("The XLSX workbook has no worksheets.");
    const relationId = sheet.getAttributeNS(RELATIONSHIPS_NS, "id") || sheet.getAttribute("r:id");
    const relation = Array.from(relations.getElementsByTagName("Relationship")).find((item) => item.getAttribute("Id") === relationId);
    if (!relation) throw new Error("The XLSX worksheet relationship is missing.");
    const target = relation.getAttribute("Target") || "";
    const sheetPath = target.startsWith("/") ? target.slice(1) : `xl/${target.replace(/^\.\//, "")}`;
    return { path: sheetPath.replace(/\/+/g, "/"), name: sheet.getAttribute("name") || "Sheet1" };
  }

  async function parse(file, onProgress) {
    if (!file || file.size === 0) throw new Error("The XLSX file is empty.");
    if (file.size > MAX_XLSX_BYTES) throw new Error("XLSX files larger than 50 MB are not opened in the popup. Save as CSV or use a smaller workbook.");
    if (typeof DecompressionStream === "undefined") throw new Error("This Chrome version cannot locally decompress XLSX files.");
    onProgress?.("Reading XLSX archive…");
    const bytes = new Uint8Array(await file.arrayBuffer());
    const entries = indexZipEntries(bytes);
    const decoder = new TextDecoder("utf-8");
    const firstSheet = await findFirstSheet(bytes, entries);
    onProgress?.(`Reading worksheet “${firstSheet.name}”…`);
    const [sheetBytes, sharedBytes] = await Promise.all([
      readZipEntry(bytes, entries, firstSheet.path),
      readZipEntry(bytes, entries, "xl/sharedStrings.xml")
    ]);
    if (!sheetBytes) throw new Error("The first worksheet could not be found in this XLSX file.");

    const sharedStrings = sharedBytes
      ? Array.from(xmlDocument(decoder.decode(sharedBytes), "sharedStrings.xml").getElementsByTagName("si"), (item) => item.textContent || "")
      : [];
    const sheet = xmlDocument(decoder.decode(sheetBytes), firstSheet.name);
    const rows = [];
    let cellsSeen = 0;
    const rowNodes = Array.from(sheet.getElementsByTagName("row"));

    for (let index = 0; index < rowNodes.length; index += 1) {
      const rowNode = rowNodes[index];
      const rowNumber = Math.max(0, Number(rowNode.getAttribute("r") || index + 1) - 1);
      const row = [];
      for (const cell of Array.from(rowNode.getElementsByTagName("c"))) {
        cellsSeen += 1;
        if (cellsSeen > MAX_XLSX_CELLS) throw new Error("This workbook exceeds the local 10 million-cell safety limit.");
        const column = columnNumber(cell.getAttribute("r"));
        const type = cell.getAttribute("t");
        const valueNode = cell.getElementsByTagName("v")[0];
        const inlineNode = cell.getElementsByTagName("is")[0];
        const rawValue = valueNode ? valueNode.textContent || "" : inlineNode ? inlineNode.textContent || "" : "";
        if (type === "s") row[column] = sharedStrings[Number(rawValue)] ?? "";
        else if (type === "b") row[column] = rawValue === "1" ? "TRUE" : "FALSE";
        else row[column] = rawValue;
      }
      rows[rowNumber] = row;
      if (index % 1000 === 0) onProgress?.(`Parsing XLSX rows: ${index.toLocaleString()} / ${rowNodes.length.toLocaleString()}`);
      if (index > 0 && index % 2000 === 0) await new Promise((resolve) => setTimeout(resolve, 0));
    }
    const width = rows.reduce((maximum, row) => Math.max(maximum, row?.length || 0), 0);
    const normalizedRows = rows.map((row) => Array.from({ length: width }, (_, column) => row?.[column] ?? ""));
    return { rows: normalizedRows, sheetName: firstSheet.name };
  }

  root.LocalXlsx = Object.freeze({ parse, MAX_XLSX_BYTES, MAX_XLSX_CELLS });
})(window);

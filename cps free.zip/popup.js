// NOWPayments is integrated through a trusted backend.
// Never put the NOWPayments API key or IPN secret in this extension.
// Replace this URL with your deployed backend URL before publishing.
const PAYMENT_BACKEND_URL = "https://clean-privasheet-backend.onrender.com";

const PRICING = Object.freeze({
  professional: { name: "Professional", users: 1, monthly: 19, yearly: 190, features: ["1 user", "Core data cleaning", "Local processing"] },
  team: { name: "Team", users: 50, monthly: 199, yearly: 1990, features: ["Up to 50 users", "Core data cleaning", "Excel export"] },
  business: { name: "Business", users: 100, monthly: 399, yearly: 3990, features: ["Up to 100 users", "Advanced cleaning", "Excel export"] },
  businessPlus: { name: "Business+", users: 500, monthly: 999, yearly: 9990, features: ["Up to 500 users", "Advanced cleaning", "Team-ready workflows"] },
  enterprise: { name: "Enterprise", users: 1000, monthly: 1999, yearly: 19990, features: ["Up to 1,000 users", "Enterprise workflows", "Excel export"] }
});

const PRICING_TIERS = Object.keys(PRICING);
const PERMANENT_LICENSE_KEY = "Arsa72";
const PERMANENT_LICENSE = Object.freeze({
  licenseKey: PERMANENT_LICENSE_KEY,
  licenseType: "Permanent",
  planType: "Permanent License",
  billingPeriod: "permanent",
  status: "Active",
  expiry: null,
  permanent: true,
  seatLimit: null
});

// Paid-license validation requires a trusted backend. Leave empty until that endpoint exists.
const LICENSE_VALIDATION_ENDPOINT = `${PAYMENT_BACKEND_URL}/api/license/validate`;
const OFFLINE_GRACE_MS = 7 * 24 * 60 * 60 * 1000;
const TEXT_EXTENSIONS = new Set(["csv", "txt", "tsv", "log"]);
const BINARY_EXTENSIONS = new Set(["pdf", "exe", "bin", "iso", "dll"]);
const NULL_VALUES = new Set(["", "null", "undefined", "#n/a", "n/a", "-"]);
const PROCESSING_CHUNK_ROWS = 2000;
const LARGE_PROCESSING_CHUNK_ROWS = 5000;
const TEXT_PARSE_CHUNK_CHARS = 250000;
const BINARY_READ_CHUNK_BYTES = 1024 * 1024;
const MAX_BINARY_STRING_LENGTH = 4096;
const MAX_BINARY_ROWS = 250000;
const PREVIEW_MAX_ROWS = 1000;
const PREVIEW_MAX_CHARACTERS = 500000;
const EXPORT_CHUNK_ROWS = 2000;
const FREE_MAX_ROWS = 500;
const FREE_ALLOWED_FILE_EXTENSIONS = new Set(["csv", "tsv", "txt", "log"]);
const FREE_ALLOWED_TYPES = new Set(["name", "email", "phone", "number", "date", "text"]);
let freePlanActive = true;
let selectedBillingPeriod = "monthly";
let selectedPricingTier = "professional";
let currentCheckoutUrl = "";
let sourceRows = [];
let cleanedRowsCache = [];
let sourceDelimiter = ",";
let isBusy = false;

document.addEventListener("DOMContentLoaded", () => {
  byId("btn-continue-free")?.addEventListener("click", continueWithFreePlan);
  byId("file-input")?.addEventListener("change", handleFileSelection);
  byId("data-input")?.addEventListener("input", invalidateCachedDataset);
  byId("btn-clean-data")?.addEventListener("click", executeDataCleaningEngine);
  byId("btn-copy-data")?.addEventListener("click", copyToClipboardUtility);
  byId("btn-download-excel")?.addEventListener("click", downloadAsExcelXlsxUtility);
  checkAppLicenseStatus();
});

function byId(id) { return document.getElementById(id); }

function initPricingUI() {
  const grid = byId("plan-grid");
  if (!grid) return;
  grid.replaceChildren();
  PRICING_TIERS.forEach((tier) => {
    const plan = PRICING[tier];
    const card = document.createElement("button");
    card.type = "button";
    card.id = `card-${tier}`;
    card.className = `plan${tier === "enterprise" ? " enterprise" : ""}`;
    card.setAttribute("aria-pressed", String(tier === selectedPricingTier));
    card.innerHTML = `<strong>${plan.name}</strong><div class="plan-price"></div><small>Up to ${plan.users.toLocaleString()} user${plan.users === 1 ? "" : "s"}</small><small class="plan-saving"></small><span class="plan-features"></span>`;
    grid.appendChild(card);
    card.addEventListener("click", () => selectPricingTier(tier));
  });
  updateBillingUI();
}

function selectBillingPeriod(period) {
  if (period !== "monthly" && period !== "yearly") return;
  selectedBillingPeriod = period;
  updateBillingUI();
}

function updateBillingUI() {
  const monthly = byId("billing-monthly");
  const yearly = byId("billing-yearly");
  if (monthly) {
    monthly.classList.toggle("active", selectedBillingPeriod === "monthly");
    monthly.setAttribute("aria-pressed", String(selectedBillingPeriod === "monthly"));
  }
  if (yearly) {
    yearly.classList.toggle("active", selectedBillingPeriod === "yearly");
    yearly.setAttribute("aria-pressed", String(selectedBillingPeriod === "yearly"));
  }
  const saving = byId("annual-saving");
  if (saving) saving.classList.toggle("hidden", selectedBillingPeriod !== "yearly");
  PRICING_TIERS.forEach((tier) => {
    const plan = PRICING[tier];
    const card = byId(`card-${tier}`);
    if (!card) return;
    const price = card.querySelector(".plan-price");
    const savingText = card.querySelector(".plan-saving");
    const features = card.querySelector(".plan-features");
    if (price) price.textContent = `$${plan[selectedBillingPeriod].toLocaleString("en-US")} / ${selectedBillingPeriod === "monthly" ? "month" : "year"}`;
    if (savingText) {
      const savingAmount = plan.monthly * 12 - plan.yearly;
      savingText.textContent = selectedBillingPeriod === "yearly" ? `Save $${savingAmount.toLocaleString("en-US")} / year` : "";
    }
    if (features) features.innerHTML = plan.features.map((feature) => `<span>✓ ${feature}</span>`).join("");
    card.classList.toggle("selected", tier === selectedPricingTier);
    card.setAttribute("aria-pressed", String(tier === selectedPricingTier));
  });
  currentCheckoutUrl = "";
  const button = byId("btn-buy-checkout");
  if (button) button.textContent = "Subscribe & Pay";
}

function selectPricingTier(tier) {
  if (!PRICING[tier]) return;
  selectedPricingTier = tier;
  PRICING_TIERS.forEach((item) => {
    const card = byId(`card-${item}`);
    if (card) {
      card.classList.toggle("selected", item === tier);
      card.setAttribute("aria-pressed", String(item === tier));
    }
  });
  currentCheckoutUrl = "";
  const plan = PRICING[tier];
  showUIMessage("lock-msg", `${plan.name} selected — ${selectedBillingPeriod} billing — up to ${plan.users.toLocaleString()} users.`, "success");
}

async function openSelectedCheckout() {
  const plan = PRICING[selectedPricingTier];
  if (!plan) return;
  if (!PAYMENT_BACKEND_URL || /YOUR-BACKEND-DOMAIN/i.test(PAYMENT_BACKEND_URL)) {
    showUIMessage("lock-msg", "Payment backend is not configured yet. Deploy the backend and set PAYMENT_BACKEND_URL in popup.js.", "error");
    return;
  }
  setBusy(true, "payment");
  try {
    const response = await fetch(`${PAYMENT_BACKEND_URL}/api/create-payment`, {
      method: "POST",
      cache: "no-store",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        plan: selectedPricingTier,
        billingPeriod: selectedBillingPeriod,
        product: "Clean PrivaSheet"
      })
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.message || `Payment creation failed (${response.status}).`);
    if (!payload.invoice_url) throw new Error("NOWPayments did not return a payment URL.");
    chrome.tabs.create({ url: payload.invoice_url });
    showUIMessage("lock-msg", `${plan.name} payment page opened. Access is activated only after the payment is confirmed.`, "success");
  } catch (error) {
    showUIMessage("lock-msg", error.message || "Unable to start payment.", "error");
  } finally {
    setBusy(false, "payment");
  }
}

function normalizeStoredLicense(stored) {
  if (stored?.licenseKey === PERMANENT_LICENSE_KEY && stored?.isUnlocked === true) {
    return PERMANENT_LICENSE;
  }
  return stored?.licenseDetails || null;
}

function isLicenseActive(license) {
  if (!license || license.status !== "Active") return false;
  if (license.permanent || license.billingPeriod === "permanent" || license.expiry === null) return true;
  const expiry = Date.parse(license.expiry);
  return Number.isFinite(expiry) && expiry > Date.now();
}

function checkAppLicenseStatus() {
  // Launch version: intentionally free-only. The paid UI is introduced by a later
  // Chrome Web Store update; do not change the existing paid backend from this build.
  freePlanActive = true;
  updateBadgeDisplay("Free Plan");
  switchScreen("screen-lock");
}

function continueWithFreePlan() {
  freePlanActive = true;
  sourceRows = [];
  cleanedRowsCache = [];
  sourceDelimiter = ",";
  if (byId("data-input")) byId("data-input").value = "";
  if (byId("data-output")) byId("data-output").value = "";
  if (byId("file-input")) byId("file-input").value = "";
  byId("report-panel")?.classList.add("hidden");
  updateBadgeDisplay("Free Plan");
  switchScreen("screen-dashboard");
}

function persistLicense(license, callback) {
  chrome.storage.local.set({
    isUnlocked: true,
    licenseKey: license.licenseKey,
    licenseKeyInstanceId: license.licenseKeyInstanceId || null,
    planType: license.planType,
    billingPeriod: license.billingPeriod,
    licenseDetails: license,
    offlineValidUntil: license.permanent ? Number.MAX_SAFE_INTEGER : (Date.parse(license.expiry) || Date.now() + OFFLINE_GRACE_MS)
  }, callback);
}

async function validatePaidLicenseRemotely(licenseKey) {
  if (!LICENSE_VALIDATION_ENDPOINT) {
    throw new Error("Paid-license validation is not configured: a trusted license-validation backend endpoint is missing.");
  }
  const response = await fetch(LICENSE_VALIDATION_ENDPOINT, {
    method: "POST",
    cache: "no-store",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ licenseKey, product: "Clean PrivaSheet" })
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.message || payload.detail || `License validation failed (${response.status}).`);
  return payload.license || payload;
}

async function handleKeyVerification() {
  const input = byId("input-key");
  const licenseKey = input?.value.trim() || "";
  if (!licenseKey) {
    showUIMessage("lock-msg", "Enter your license key.", "error");
    return;
  }

  setBusy(true, "license");
  try {
    if (licenseKey === PERMANENT_LICENSE_KEY) {
      persistLicense(PERMANENT_LICENSE, () => {
        if (input) input.value = "";
        updateBadgeDisplay("Permanent License (always active)");
        showUIMessage("lock-msg", "Permanent license activated successfully.", "success");
        switchScreen("screen-dashboard");
      });
      return;
    }

    const license = await validatePaidLicenseRemotely(licenseKey);
    const normalized = {
      licenseKey,
      licenseKeyInstanceId: license.licenseKeyInstanceId || license.instanceId || null,
      planType: license.planType || license.plan || "Paid License",
      billingPeriod: license.billingPeriod || license.period || null,
      status: license.status || "Active",
      expiry: license.expiry || license.expiresAt || null,
      seatLimit: license.seatLimit ?? license.seats ?? null,
      permanent: license.permanent === true || license.billingPeriod === "permanent",
      licenseType: license.licenseType || (license.permanent ? "Permanent" : "Subscription")
    };
    if (!isLicenseActive(normalized)) throw new Error("This license is invalid or expired.");
    persistLicense(normalized, () => {
      if (input) input.value = "";
      updateBadgeDisplay(`${normalized.planType} (${normalized.billingPeriod || normalized.licenseType})`);
      showUIMessage("lock-msg", "License activated successfully.", "success");
      switchScreen("screen-dashboard");
    });
  } catch (error) {
    showUIMessage("lock-msg", error.message || "License activation failed.", "error");
  } finally {
    setBusy(false, "license");
  }
}

async function getOrCreateDeviceName() {
  const stored = await new Promise((resolve) => chrome.storage.local.get("deviceId", resolve));
  let deviceId = stored.deviceId;
  if (!deviceId) {
    deviceId = typeof crypto.randomUUID === "function"
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    await new Promise((resolve) => chrome.storage.local.set({ deviceId }, resolve));
  }
  return `Clean PrivaSheet Chrome (${deviceId.slice(0, 8)})`;
}

function clearStoredLicense(callback) {
  chrome.storage.local.remove(
    ["isUnlocked", "offlineValidUntil", "planType", "licenseKey", "licenseKeyInstanceId"],
    callback
  );
}

async function handleFileSelection(event) {
  const file = event.target.files[0];
  if (!file || isBusy) return;
  const extension = (file.name.split(".").pop() || "").toLowerCase();
  if (freePlanActive && !FREE_ALLOWED_FILE_EXTENSIONS.has(extension)) {
    showUIMessage("dash-msg", "Free Plan supports CSV, TSV, TXT and LOG files. Excel and advanced file scanning are part of Pro.", "error");
    event.target.value = "";
    return;
  }
  if (extension !== "xlsx" && !TEXT_EXTENSIONS.has(extension) && !BINARY_EXTENSIONS.has(extension)) {
    showUIMessage("dash-msg", "Choose a supported file.", "error");
    event.target.value = "";
    return;
  }

  invalidateCachedDataset();
  setBusy(true, "data");
  try {
    if (extension === "xlsx") {
      if (!window.LocalXlsx?.parse) throw new Error("The local XLSX reader is unavailable.");
      const result = await window.LocalXlsx.parse(file, (message) => showProgress(message));
      sourceDelimiter = ",";
      sourceRows = result.rows || [];
    } else if (TEXT_EXTENSIONS.has(extension)) {
      showProgress(`Reading ${file.name}…`);
      const text = await file.text();
      sourceDelimiter = extension === "tsv" ? "\t" : detectDelimiter(text);
      sourceRows = await parseDelimitedAsync(text, sourceDelimiter, "Parsing file");
    } else {
      sourceDelimiter = ",";
      sourceRows = await extractReadableBinaryRows(file);
    }
    if (freePlanActive && sourceRows.length > FREE_MAX_ROWS) {
      sourceRows = [];
      showUIMessage("dash-msg", `Free Plan is limited to ${FREE_MAX_ROWS.toLocaleString()} rows per job. Upgrade to Pro for larger datasets.`, "error");
      event.target.value = "";
      hideProgress();
      return;
    }
    showSourcePreview();
    if (!sourceRows.length) {
      showUIMessage("dash-msg", "No readable rows were found in this file.", "error");
      hideProgress();
      return;
    }
    const limitMessage = sourceRows.binaryExtractionLimited
      ? " Extraction stopped at the safety limit of 250,000 text blocks."
      : "";
    showProgress(`${file.name}: ${sourceRows.length.toLocaleString()} rows ready. Click Clean.${limitMessage}`);
  } catch (error) {
    hideProgress();
    showUIMessage("dash-msg", `Could not read this file: ${error.message}`, "error");
  } finally {
    setBusy(false, "data");
  }
}

async function extractReadableBinaryRows(file) {
  const rows = [];
  let asciiCarry = "";
  for (let offset = 0; offset < file.size && rows.length < MAX_BINARY_ROWS; offset += BINARY_READ_CHUNK_BYTES) {
    const end = Math.min(offset + BINARY_READ_CHUNK_BYTES, file.size);
    const bytes = new Uint8Array(await file.slice(offset, end).arrayBuffer());
    asciiCarry = scanAsciiStrings(bytes, asciiCarry, rows);
    scanUtf16Strings(bytes, true, rows);
    scanUtf16Strings(bytes, false, rows);
    showProgress(`Scanning binary data: ${Math.round((end / Math.max(file.size, 1)) * 100)}% (${rows.length.toLocaleString()} text blocks)`);
    await yieldToPopup();
  }
  appendBinaryBlock(rows, asciiCarry);
  if (rows.length >= MAX_BINARY_ROWS) rows.binaryExtractionLimited = true;
  return rows;
}

function scanAsciiStrings(bytes, carry, rows) {
  let block = carry;
  for (let index = 0; index < bytes.length; index += 1) {
    const byte = bytes[index];
    if (isPrintableByte(byte)) {
      block += String.fromCharCode(byte);
      if (block.length >= MAX_BINARY_STRING_LENGTH) {
        appendBinaryBlock(rows, block);
        block = "";
      }
    } else {
      appendBinaryBlock(rows, block);
      block = "";
      if (rows.length >= MAX_BINARY_ROWS) return "";
    }
  }
  return block;
}

function scanUtf16Strings(bytes, littleEndian, rows) {
  let block = "";
  for (let index = 0; index + 1 < bytes.length && rows.length < MAX_BINARY_ROWS;) {
    const characterByte = littleEndian ? bytes[index] : bytes[index + 1];
    const zeroByte = littleEndian ? bytes[index + 1] : bytes[index];
    if (zeroByte === 0 && isPrintableByte(characterByte)) {
      block += String.fromCharCode(characterByte);
      index += 2;
      if (block.length >= MAX_BINARY_STRING_LENGTH) {
        appendBinaryBlock(rows, block);
        block = "";
      }
    } else {
      appendBinaryBlock(rows, block);
      block = "";
      index += 1;
    }
  }
  appendBinaryBlock(rows, block);
}

function isPrintableByte(byte) {
  return byte === 9 || (byte >= 32 && byte <= 126);
}

function appendBinaryBlock(rows, value) {
  const block = String(value || "").replace(/[\t\r\n]+/g, " ").replace(/\s{2,}/g, " ").trim();
  if (block.length < 4 || rows.length >= MAX_BINARY_ROWS) return;
  const previous = rows.length ? rows[rows.length - 1][0] : "";
  if (block !== previous) rows.push([block]);
}

function detectDelimiter(text) {
  const sample = text.split(/\r?\n/).slice(0, 20).join("\n");
  const candidates = ["\t", ",", ";", "|"]
    .map((delimiter) => ({ delimiter, count: sample.split(delimiter).length - 1 }))
    .sort((left, right) => right.count - left.count);
  return candidates[0].count > 0 ? candidates[0].delimiter : ",";
}

function parseDelimitedAsync(text, delimiter, label) {
  return new Promise((resolve) => {
    const rows = [];
    let row = [];
    let value = "";
    let quoted = false;
    let index = 0;

    const processChunk = () => {
      const end = Math.min(index + TEXT_PARSE_CHUNK_CHARS, text.length);
      while (index < end) {
        const character = text[index];
        const next = text[index + 1];
        if (character === '"') {
          if (quoted && next === '"') {
            value += '"';
            index += 2;
            continue;
          }
          quoted = !quoted;
        } else if (character === delimiter && !quoted) {
          row.push(value);
          value = "";
        } else if ((character === "\n" || character === "\r") && !quoted) {
          if (character === "\r" && next === "\n") index += 1;
          row.push(value);
          if (row.some((cell) => cell !== "")) rows.push(row);
          row = [];
          value = "";
        } else {
          value += character;
        }
        index += 1;
      }
      showProgress(`${label}: ${Math.round((index / Math.max(text.length, 1)) * 100)}%`);
      if (index < text.length) {
        setTimeout(processChunk, 0);
        return;
      }
      if (value !== "" || row.length) {
        row.push(value);
        if (row.some((cell) => cell !== "")) rows.push(row);
      }
      resolve(rows);
    };
    processChunk();
  });
}

async function executeDataCleaningEngine() {
  if (isBusy) return;
  try {
    if (!sourceRows.length) {
      const text = document.getElementById("data-input").value;
      if (!text.trim()) {
        showUIMessage("dash-msg", "Paste data or upload a supported file first.", "error");
        return;
      }
      setBusy(true, "data");
      sourceDelimiter = detectDelimiter(text);
      sourceRows = await parseDelimitedAsync(text, sourceDelimiter, "Parsing pasted data");
      if (freePlanActive && sourceRows.length > FREE_MAX_ROWS) {
        sourceRows = [];
        hideProgress();
        setBusy(false, "data");
        showUIMessage("dash-msg", `Free Plan is limited to ${FREE_MAX_ROWS.toLocaleString()} rows per job. Upgrade to Pro for larger datasets.`, "error");
        return;
      }
      if (!sourceRows.length) {
        hideProgress();
        setBusy(false, "data");
        showUIMessage("dash-msg", "No data rows were found to clean.", "error");
        return;
      }
    } else {
      setBusy(true, "data");
    }

    // Work on a copy so the original imported/typed data remains intact in memory.
    cleanedRowsCache = sourceRows.map((row) => row.slice());
    const hasHeader = document.getElementById("first-row-header")?.checked !== false;
    // When manually entering a single row/value, there is no separate data row
    // to clean if we blindly treat row 1 as a header. Clean the single row too;
    // for multi-row data, preserve the explicitly selected header row.
    const preserveHeader = hasHeader && cleanedRowsCache.length > 1;
    const columnHeaders = preserveHeader ? [...(cleanedRowsCache[0] || [])] : [];
    const chunkSize = cleanedRowsCache.length >= 50000 ? LARGE_PROCESSING_CHUNK_ROWS : PROCESSING_CHUNK_ROWS;
    let rowIndex = preserveHeader ? 1 : 0;
    const cleanChunk = () => {
      const end = Math.min(rowIndex + chunkSize, cleanedRowsCache.length);
      for (; rowIndex < end; rowIndex += 1) {
        cleanedRowsCache[rowIndex] = cleanedRowsCache[rowIndex].map((cell, columnIndex) => cleanCell(cell, columnHeaders[columnIndex] || ""));
      }
      showProgress(`Cleaning ${rowIndex.toLocaleString()} / ${cleanedRowsCache.length.toLocaleString()} rows…`);
      if (rowIndex < cleanedRowsCache.length) {
        setTimeout(cleanChunk, 0);
        return;
      }
      const cleanedPreview = makePreview(cleanedRowsCache, sourceDelimiter || ",");
      // Put the cleaned result directly back into the editable data area so the
      // user can immediately see that cleaning happened. Keep the full cleaned
      // dataset separately for Excel export/copy.
      byId("data-input").value = cleanedPreview;
      byId("data-output").value = cleanedPreview;
      byId("report-panel")?.classList.remove("hidden");
      const changedCells = countChangedCells(sourceRows, cleanedRowsCache);
      const report = byId("report-summary");
      if (report) report.textContent = `${cleanedRowsCache.length.toLocaleString()} rows processed • ${changedCells.toLocaleString()} cells normalized • processing stayed local.`;
      showUIMessage("dash-msg", changedCells ? `Cleaned ${changedCells.toLocaleString()} cells across ${cleanedRowsCache.length.toLocaleString()} rows.` : "Cleaning completed. No changes were needed for the supplied data.", "success");
      hideProgress();
      setBusy(false, "data");
    };
    cleanChunk();
  } catch (error) {
    hideProgress();
    setBusy(false, "data");
    showUIMessage("dash-msg", `Could not clean this data: ${error.message}`, "error");
  }
}

function countChangedCells(beforeRows, afterRows) {
  let changed = 0;
  const rowCount = Math.max(beforeRows.length, afterRows.length);
  for (let rowIndex = 0; rowIndex < rowCount; rowIndex += 1) {
    const before = beforeRows[rowIndex] || [];
    const after = afterRows[rowIndex] || [];
    const cellCount = Math.max(before.length, after.length);
    for (let columnIndex = 0; columnIndex < cellCount; columnIndex += 1) {
      if (String(before[columnIndex] ?? "") !== String(after[columnIndex] ?? "")) changed += 1;
    }
  }
  return changed;
}

function cleanCell(value, columnName = "") {
  const original = value === null || value === undefined ? "" : String(value);
  const trimmed = original.trim();
  if (NULL_VALUES.has(trimmed.toLowerCase())) return original;

  let text = original.normalize ? original.normalize("NFKC") : original;
  text = text
    .replace(/[\u200B-\u200D\u2060\uFEFF]/g, "")
    .replace(/[\u00A0\u1680\u2000-\u200A\u202F\u205F\u3000]/g, " ")
    .replace(/[\r\n\t]+/g, " ")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F]/g, "")
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/\s+/g, " ")
    .trim();
  if (!text) return text;

  // 24 supported data types. Header names are used when available so ordinary
  // text such as "May" or "100" is not accidentally converted.
  const detectedType = detectDataType(text, columnName);
  const type = freePlanActive && !FREE_ALLOWED_TYPES.has(detectedType) ? "text" : detectedType;
  switch (type) {
    case "name": return normalizeName(text);
    case "email": return normalizeEmail(text) || text.toLowerCase();
    case "phone": return normalizePhone(text) || text;
    case "url": return normalizeUrl(text) || text;
    case "address": return normalizeAddress(text);
    case "city": return normalizeName(text);
    case "state": return normalizeName(text);
    case "country": return normalizeCountry(text);
    case "postal": return normalizePostalCode(text);
    case "date": return normalizeDate(text) || text;
    case "time": return normalizeTime(text) || text;
    case "datetime": return normalizeDateTime(text) || text;
    case "currency": return normalizeCurrency(text) || text;
    case "percentage": return normalizePercentage(text) || text;
    case "number": return normalizeNumber(text) || text;
    case "integer": return normalizeInteger(text) || text;
    case "boolean": return normalizeBoolean(text) || text;
    case "gender": return normalizeGender(text) || text;
    case "company": return normalizeCompany(text);
    case "credit_card": return maskCreditCard(text) || text;
    case "ip": return normalizeIp(text) || text;
    case "uuid": return normalizeUuid(text) || text.toLowerCase();
    case "id": return normalizeId(text);
    default: return text;
  }
}

function normalizeName(text) {
  return text.toLocaleLowerCase().replace(/(^|[\s'-])\p{L}/gu, (character) => character.toLocaleUpperCase());
}

function headerMatches(columnName, patterns) {
  const h = String(columnName || "").toLowerCase().replace(/[_-]+/g, " ").trim();
  return patterns.some((pattern) => new RegExp(`\\b${pattern}\\b`, "i").test(h));
}

function detectDataType(text, columnName) {
  const h = String(columnName || "").toLowerCase().replace(/[_-]+/g, " ");
  if (headerMatches(h, ["email", "e mail", "mail"])) return "email";
  if (headerMatches(h, ["phone", "mobile", "telephone", "tel", "contact number"])) return "phone";
  if (headerMatches(h, ["url", "website", "web", "link"])) return "url";
  if (headerMatches(h, ["credit card", "card number", "card no"])) return "credit_card";
  if (headerMatches(h, ["address", "street", "address line"])) return "address";
  if (headerMatches(h, ["city", "town"])) return "city";
  if (headerMatches(h, ["state", "province", "region"])) return "state";
  if (headerMatches(h, ["country", "nation"])) return "country";
  if (headerMatches(h, ["zip", "zipcode", "postal", "pincode", "pin code"])) return "postal";
  if (headerMatches(h, ["datetime", "date time", "timestamp"])) return "datetime";
  if (headerMatches(h, ["date", "dob", "birth date"])) return "date";
  if (headerMatches(h, ["time"])) return "time";
  if (headerMatches(h, ["currency", "amount", "price", "cost", "revenue", "salary"])) return "currency";
  if (headerMatches(h, ["percentage", "percent", "rate"])) return "percentage";
  if (headerMatches(h, ["integer", "count", "quantity", "age"])) return "integer";
  if (headerMatches(h, ["number", "numeric", "score", "value"])) return "number";
  if (headerMatches(h, ["boolean", "active", "enabled", "verified", "approved"])) return "boolean";
  if (headerMatches(h, ["gender", "sex"])) return "gender";
  if (headerMatches(h, ["company", "organization", "organisation", "employer"])) return "company";
  if (headerMatches(h, ["ip", "ip address"])) return "ip";
  if (headerMatches(h, ["uuid", "guid"])) return "uuid";
  if (headerMatches(h, ["id", "identifier", "code", "reference", "ref"])) return "id";
  if (headerMatches(h, ["name", "full name", "first name", "last name", "surname"])) return "name";

  if (normalizeEmail(text)) return "email";
  if (normalizeUrl(text)) return "url";
  if (maskCreditCard(text)) return "credit_card";
  if (normalizePhone(text)) return "phone";
  if (normalizeIp(text)) return "ip";
  if (normalizeUuid(text)) return "uuid";
  if (normalizeBoolean(text)) return "boolean";
  if (normalizePercentage(text)) return "percentage";
  if (normalizeCurrency(text)) return "currency";
  if (normalizeDateTime(text)) return "datetime";
  if (normalizeDate(text)) return "date";
  if (normalizeTime(text)) return "time";
  return isTitleCaseCandidate(text) ? "name" : "text";
}

function normalizeEmail(text) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text) ? text.toLowerCase() : null;
}

function normalizeUrl(text) {
  if (!/^(?:https?:\/\/|www\.)/i.test(text)) return null;
  try {
    const url = new URL(/^www\./i.test(text) ? `https://${text}` : text);
    const pathname = url.pathname.replace(/\/{2,}/g, "/").replace(/\/$/, "");
    return `${url.protocol.toLowerCase()}//${url.host.toLowerCase()}${pathname}${url.search}${url.hash}`;
  } catch (_) { return null; }
}

function maskCreditCard(text) {
  const digits = text.replace(/[\s-]/g, "");
  if (!/^\d{13,19}$/.test(digits) || !passesLuhnCheck(digits)) return null;
  return `${digits.slice(0, 6)}••••••${digits.slice(-4)}`;
}

function passesLuhnCheck(digits) {
  let total = 0, shouldDouble = false;
  for (let index = digits.length - 1; index >= 0; index -= 1) {
    let value = Number(digits[index]);
    if (shouldDouble) value = value > 4 ? value * 2 - 9 : value * 2;
    total += value;
    shouldDouble = !shouldDouble;
  }
  return total % 10 === 0;
}

function normalizePhone(text) {
  if (!/^[+()\d.\s-]+$/.test(text)) return null;
  const hadPlus = /^\s*\+/.test(text);
  let digits = text.replace(/\D/g, "");
  if (digits.startsWith("00")) {
    digits = digits.slice(2);
    return digits.length >= 8 && digits.length <= 15 ? `+${digits}` : null;
  }
  if (hadPlus && digits.length >= 8 && digits.length <= 15) return `+${digits}`;
  if (digits.length === 12 && digits.startsWith("91")) return `+91 ${digits.slice(2)}`;
  if (digits.length === 10 && /^[6-9]/.test(digits)) return `+91 ${digits}`;
  return null;
}

function normalizeAddress(text) {
  return text.replace(/\s*,\s*/g, ", ").replace(/\s{2,}/g, " ").trim();
}

function normalizeCountry(text) {
  const aliases = { india: "India", "united states": "United States", usa: "United States", us: "United States", uk: "United Kingdom", "united kingdom": "United Kingdom", canada: "Canada", australia: "Australia", germany: "Germany", france: "France", japan: "Japan", china: "China" };
  return aliases[text.toLowerCase()] || normalizeName(text);
}

function normalizePostalCode(text) {
  const compact = text.toUpperCase().replace(/\s+/g, "");
  return /^[A-Z0-9 -]{3,10}$/.test(compact) ? compact : text;
}

function normalizeTime(text) {
  const m = text.match(/^(\d{1,2})[:.](\d{2})(?:[:.](\d{2}))?\s*(AM|PM)?$/i);
  if (!m) return null;
  let hour = Number(m[1]), minute = Number(m[2]), second = Number(m[3] || 0);
  const ap = m[4] ? m[4].toUpperCase() : "";
  if (minute > 59 || second > 59) return null;
  if (ap) { if (hour < 1 || hour > 12) return null; if (ap === "PM" && hour < 12) hour += 12; if (ap === "AM" && hour === 12) hour = 0; }
  else if (hour > 23) return null;
  return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}:${String(second).padStart(2, "0")}`;
}

function normalizeDateTime(text) {
  const m = text.match(/^(.*?)[T\s]+(\d{1,2}[:.]\d{2}(?::\d{2})?(?:\s*[AP]M)?)$/i);
  if (!m) return null;
  const date = normalizeDate(m[1].trim());
  const time = normalizeTime(m[2].trim());
  return date && time ? `${date} ${time}` : null;
}

function normalizeDate(text) {
  let match = text.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})(?:[T\s].*)?$/);
  if (match) return validIsoDate(Number(match[1]), Number(match[2]), Number(match[3]));
  match = text.match(/^(\d{4})(\d{2})(\d{2})$/);
  if (match) return validIsoDate(Number(match[1]), Number(match[2]), Number(match[3]));
  match = text.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$/);
  if (match) {
    const first = Number(match[1]), second = Number(match[2]), year = Number(match[3]);
    const month = first > 12 ? second : first, day = first > 12 ? first : second;
    return validIsoDate(year, month, day);
  }
  match = text.match(/^(\d{1,2})\s+([A-Za-z]{3,9}),?\s*(\d{4})$/);
  if (match) { const month = monthNumber(match[2]); return month ? validIsoDate(Number(match[3]), month, Number(match[1])) : null; }
  return null;
}

function validIsoDate(year, month, day) {
  const date = new Date(Date.UTC(year, month - 1, day));
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) return null;
  return `${String(year).padStart(4, "0")}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

function monthNumber(name) {
  const months = { jan: 1, january: 1, feb: 2, february: 2, mar: 3, march: 3, apr: 4, april: 4, may: 5, jun: 6, june: 6, jul: 7, july: 7, aug: 8, august: 8, sep: 9, sept: 9, september: 9, oct: 10, october: 10, nov: 11, november: 11, dec: 12, december: 12 };
  return months[name.toLowerCase()] || null;
}

function normalizeCurrency(text) {
  const match = text.match(/^([₹$€£])\s*(-?)(\d[\d,]*)(?:\.(\d+))?$/);
  if (!match) return null;
  const [, symbol, sign, whole, fraction = ""] = match;
  const amount = Number(`${sign}${whole.replace(/,/g, "")}.${fraction || "0"}`);
  if (!Number.isFinite(amount)) return null;
  const locale = symbol === "₹" ? "en-IN" : "en-US";
  return `${amount < 0 ? "-" : ""}${symbol}${Math.abs(amount).toLocaleString(locale, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function normalizePercentage(text) {
  const m = text.match(/^(-?\d+(?:\.\d+)?)\s*%$/);
  if (!m) return null;
  const n = Number(m[1]);
  return Number.isFinite(n) ? `${n}%` : null;
}

function normalizeNumber(text) {
  const compact = text.replace(/,/g, "");
  if (!/^-?\d+(?:\.\d+)?$/.test(compact)) return null;
  const n = Number(compact);
  return Number.isFinite(n) ? String(n) : null;
}

function normalizeInteger(text) {
  const compact = text.replace(/,/g, "");
  if (!/^-?\d+$/.test(compact)) return null;
  const n = Number(compact);
  return Number.isSafeInteger(n) ? String(n) : null;
}

function normalizeBoolean(text) {
  if (/^(true|yes|y|1)$/i.test(text)) return "TRUE";
  if (/^(false|no|n|0)$/i.test(text)) return "FALSE";
  return null;
}

function normalizeGender(text) {
  const value = text.toLowerCase();
  if (/^(m|male|man)$/i.test(value)) return "Male";
  if (/^(f|female|woman)$/i.test(value)) return "Female";
  if (/^(non[- ]?binary|nb)$/i.test(value)) return "Non-binary";
  if (/^(other)$/i.test(value)) return "Other";
  if (/^(prefer not to say|unknown)$/i.test(value)) return "Not specified";
  return null;
}

function normalizeCompany(text) {
  return text.replace(/\b(ltd|limited|inc|incorporated|llc|corp|corporation|pvt|private)\.?$/i, (m) => m.replace(/\./g, "").replace(/^./, (c) => c.toUpperCase())).replace(/\s+/g, " ").trim();
}

function normalizeIp(text) {
  const parts = text.split(".");
  if (parts.length !== 4 || parts.some((part) => !/^\d{1,3}$/.test(part) || Number(part) > 255)) return null;
  return parts.map((part) => String(Number(part))).join(".");
}

function normalizeUuid(text) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(text) ? text.toLowerCase() : null;
}

function normalizeId(text) {
  return text.replace(/\s+/g, "").replace(/[^\p{L}\p{N}_./-]/gu, "");
}

function isTitleCaseCandidate(text) {
  return text.length <= 160 && /^[\p{L}][\p{L}' -]*$/u.test(text) && !/^[A-Z]{2,5}$/.test(text);
}

function makePreview(rows, delimiter) {
  const lines = [];
  let characterCount = 0;
  for (let index = 0; index < rows.length && index < PREVIEW_MAX_ROWS; index += 1) {
    const line = rows[index].map(csvEscape).join(delimiter);
    if (characterCount + line.length > PREVIEW_MAX_CHARACTERS) break;
    lines.push(line);
    characterCount += line.length + 1;
  }
  const truncated = lines.length < rows.length;
  return `${lines.join("\n")}${truncated ? "\n… preview limited; export and copy contain every cleaned row." : ""}`;
}

function showSourcePreview() {
  document.getElementById("data-input").value = makePreview(sourceRows, sourceDelimiter);
  document.getElementById("data-output").value = "";
  byId("report-panel")?.classList.add("hidden");
}

function invalidateCachedDataset() {
  if (isBusy) return;
  sourceRows = [];
  cleanedRowsCache = [];
  document.getElementById("data-output").value = "";
}

function protectSpreadsheetValue(value) {
  const text = String(value ?? "");
  if (NULL_VALUES.has(text.trim().toLowerCase())) return text;
  return /^[=+@]/.test(text) || /^-[A-Za-z]/.test(text) ? `'${text}` : text;
}

function csvEscape(value) {
  const text = protectSpreadsheetValue(value);
  return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function buildDelimitedBlob(rows, delimiter, mimeType) {
  const parts = ["\uFEFF"];
  for (let start = 0; start < rows.length; start += EXPORT_CHUNK_ROWS) {
    const end = Math.min(start + EXPORT_CHUNK_ROWS, rows.length);
    const chunk = rows.slice(start, end).map((row) => row.map((value) => {
      const protectedValue = protectSpreadsheetValue(value);
      return delimiter === "," ? csvEscape(protectedValue) : protectedValue;
    }).join(delimiter)).join("\r\n");
    parts.push(chunk);
    if (end < rows.length) parts.push("\r\n");
  }
  return new Blob(parts, { type: mimeType });
}

function xmlEscape(value) {
  return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

function columnLetters(index) {
  let n = index + 1;
  let result = "";
  while (n > 0) {
    const remainder = (n - 1) % 26;
    result = String.fromCharCode(65 + remainder) + result;
    n = Math.floor((n - 1) / 26);
  }
  return result;
}

function crc32(bytes) {
  let crc = 0xFFFFFFFF;
  for (let i = 0; i < bytes.length; i += 1) {
    crc ^= bytes[i];
    for (let bit = 0; bit < 8; bit += 1) crc = (crc >>> 1) ^ (0xEDB88320 & -(crc & 1));
  }
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function writeUInt16(target, offset, value) {
  target[offset] = value & 255; target[offset + 1] = (value >>> 8) & 255;
}
function writeUInt32(target, offset, value) {
  target[offset] = value & 255; target[offset + 1] = (value >>> 8) & 255; target[offset + 2] = (value >>> 16) & 255; target[offset + 3] = (value >>> 24) & 255;
}

function makeZip(files) {
  const encoder = new TextEncoder();
  const chunks = [];
  const central = [];
  let offset = 0;
  files.forEach(({ name, content }) => {
    const nameBytes = encoder.encode(name);
    const data = typeof content === "string" ? encoder.encode(content) : content;
    const header = new Uint8Array(30 + nameBytes.length);
    writeUInt32(header, 0, 0x04034b50); writeUInt16(header, 4, 20); writeUInt16(header, 6, 0); writeUInt16(header, 8, 0);
    writeUInt16(header, 10, 0); writeUInt16(header, 12, 0); writeUInt32(header, 14, crc32(data)); writeUInt32(header, 18, data.length); writeUInt32(header, 22, data.length);
    writeUInt16(header, 26, nameBytes.length); writeUInt16(header, 28, 0); header.set(nameBytes, 30);
    chunks.push(header, data);
    const entry = new Uint8Array(46 + nameBytes.length);
    writeUInt32(entry, 0, 0x02014b50); writeUInt16(entry, 4, 20); writeUInt16(entry, 6, 20); writeUInt16(entry, 8, 0); writeUInt16(entry, 10, 0); writeUInt16(entry, 12, 0);
    writeUInt16(entry, 14, 0); writeUInt32(entry, 16, crc32(data)); writeUInt32(entry, 20, data.length); writeUInt32(entry, 24, data.length);
    writeUInt16(entry, 28, nameBytes.length); writeUInt16(entry, 30, 0); writeUInt16(entry, 32, 0); writeUInt16(entry, 34, 0); writeUInt16(entry, 36, 0); writeUInt32(entry, 38, 0); writeUInt32(entry, 42, offset); entry.set(nameBytes, 46);
    central.push(entry);
    offset += header.length + data.length;
  });
  const centralStart = offset;
  central.forEach((entry) => { chunks.push(entry); offset += entry.length; });
  const end = new Uint8Array(22);
  writeUInt32(end, 0, 0x06054b50); writeUInt16(end, 4, 0); writeUInt16(end, 6, 0); writeUInt16(end, 8, files.length); writeUInt16(end, 10, files.length); writeUInt32(end, 12, offset - centralStart); writeUInt32(end, 16, centralStart); writeUInt16(end, 20, 0);
  chunks.push(end);
  return new Blob(chunks, { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
}

function buildXlsxBlob(rows) {
  const sheetRows = rows.map((row, rowIndex) => {
    const cells = row.map((value, columnIndex) => `<c r="${columnLetters(columnIndex)}${rowIndex + 1}" t="inlineStr"><is><t xml:space="preserve">${xmlEscape(protectSpreadsheetValue(value))}</t></is></c>`).join("");
    return `<row r="${rowIndex + 1}">${cells}</row>`;
  }).join("");
  const worksheet = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${sheetRows}</sheetData></worksheet>`;
  const workbook = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Cleaned Data" sheetId="1" r:id="rId1"/></sheets></workbook>`;
  const rels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>`;
  const rootRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
  const contentTypes = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>`;
  return makeZip([
    { name: "[Content_Types].xml", content: contentTypes },
    { name: "_rels/.rels", content: rootRels },
    { name: "xl/workbook.xml", content: workbook },
    { name: "xl/_rels/workbook.xml.rels", content: rels },
    { name: "xl/worksheets/sheet1.xml", content: worksheet }
  ]);
}

function downloadAsExcelXlsxUtility() {
  if (!cleanedRowsCache.length) {
    showUIMessage("dash-msg", "Clean data before downloading an Excel sheet.", "error");
    return;
  }
  try {
    const url = URL.createObjectURL(buildXlsxBlob(cleanedRowsCache));
    const link = document.createElement("a");
    link.href = url; link.download = "Clean_PrivaSheet_Export.xlsx"; document.body.appendChild(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    showUIMessage("dash-msg", `Excel workbook downloaded with all ${cleanedRowsCache.length.toLocaleString()} cleaned rows.`, "success");
  } catch (error) {
    showUIMessage("dash-msg", `Could not create the Excel workbook: ${error.message}`, "error");
  }
}

function downloadAsExcelCSVUtility() {
  if (!cleanedRowsCache.length) {
    showUIMessage("dash-msg", "Clean data before exporting.", "error");
    return;
  }
  const url = URL.createObjectURL(buildDelimitedBlob(cleanedRowsCache, ",", "text/csv;charset=utf-8"));
  const link = document.createElement("a");
  link.href = url;
  link.download = "Clean_PrivaSheet_Export.csv";
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 0);
  showUIMessage("dash-msg", `Excel-compatible CSV downloaded with all ${cleanedRowsCache.length.toLocaleString()} rows.`, "success");
}

async function copyToClipboardUtility() {
  if (!cleanedRowsCache.length) {
    showUIMessage("dash-msg", "Clean data before copying.", "error");
    return;
  }
  try {
    const blob = buildDelimitedBlob(cleanedRowsCache, "\t", "text/plain;charset=utf-8");
    if (navigator.clipboard.write && typeof ClipboardItem !== "undefined") {
      await navigator.clipboard.write([new ClipboardItem({ "text/plain": blob })]);
    } else {
      await navigator.clipboard.writeText(await blob.text());
    }
    showUIMessage("dash-msg", "Full cleaned dataset copied to clipboard.", "success");
  } catch (_) {
    showUIMessage("dash-msg", "Clipboard access was blocked by Chrome.", "error");
  }
}

function yieldToPopup() {
  return new Promise((resolve) => setTimeout(resolve, 0));
}

function setBusy(busy, area) {
  isBusy = busy;
  if (area === "license") {
    document.getElementById("btn-verify-key").disabled = busy;
    document.getElementById("input-key").disabled = busy;
    return;
  }
  ["file-input", "data-input", "btn-clean-data", "btn-copy-data", "btn-download-excel"].forEach((id) => {
    const element = byId(id);
    if (element) element.disabled = busy;
  });
}

function switchScreen(id) {
  document.querySelectorAll(".screen").forEach((screen) => screen.classList.remove("active"));
  document.getElementById(id).classList.add("active");
}
function updateBadgeDisplay(text) { document.getElementById("license-badge").textContent = `🔒 Clean PrivaSheet Active: ${text}`; }
function showUIMessage(id, text, kind) { const element = document.getElementById(id); element.textContent = text; element.className = `msg ${kind}`; }
function showProgress(text) { const element = document.getElementById("progress"); element.textContent = text; element.style.display = "inline-block"; }
function hideProgress() { document.getElementById("progress").style.display = "none"; }
